package com.sgps.leetcode.leetcodepro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeetcodeProApplicationTests {

	@Test
	void contextLoads() {
	}

}
